<div id="footer" style="margin-bottom:70px;">
    <div class="space-6"></div>
    <div class="col-xs-12">
        <div class="row">
            <div class="col-xs-6"><?= 'យល់ព្រមទិញដោយ' . "<br>" . 'ហត្ថលេខានិងឈ្មោះ' ?></div>
            <div class="col-xs-6 align-right"><?= 'អ្នកលក់'. "<br>" . 'ហត្ថលេខានិងឈ្មោះ '?> </div>
        </div>
    </div>
</div>
